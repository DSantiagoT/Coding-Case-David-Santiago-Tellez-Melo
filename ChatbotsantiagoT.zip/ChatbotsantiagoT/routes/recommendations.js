const express = require('express');
const routerHandler = express.Router();
const catalogService = require('../services/catalog');

// Endpoint para obtener sugerencias personalizadas
routerHandler.get('/:userIdentifier', (request, response) => {
  const suggestions = catalogService.fetchUserSuggestions(request.params.userIdentifier);
  response.json({ 
    status: true, 
    payload: suggestions 
  });
});

// Endpoint para configurar preferencias de usuario
routerHandler.post('/settings', (request, response) => {
  const { userIdentifier, userSettings } = request.body;
  
  if (!userIdentifier) {
    return response.status(400).json({ 
      status: false, 
      message: 'User identifier is mandatory' 
    });
  }
  
  const userProfile = catalogService.createUserProfile(userIdentifier, userSettings);
  
  response.json({ 
    status: true, 
    payload: { 
      notification: 'User settings have been updated', 
      profile: {
        identifier: userProfile.identifier, 
        configuration: userProfile.configuration
      }
    }
  });
});

// Endpoint para registrar actividad del usuario
routerHandler.post('/activity', (request, response) => {
  const { userIdentifier, activityType, itemIdentifier } = request.body;
  
  if (!userIdentifier || !activityType || !itemIdentifier) {
    return response.status(400).json({ 
      status: false, 
      message: 'User identifier, activity type and item identifier are mandatory fields' 
    });
  }
  
  const updatedProfile = catalogService.recordUserActivity(userIdentifier, activityType, itemIdentifier);
  
  response.json({
    status: true,
    payload: {
      notification: 'User activity has been recorded successfully',
      modifiedSettings: updatedProfile.configuration
    }
  });
});

module.exports = routerHandler;