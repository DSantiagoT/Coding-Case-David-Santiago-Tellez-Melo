const express = require('express');
const routerHandler = express.Router();
const catalogService = require('../services/catalog');

routerHandler.get('/catalog', (request, response) => {
  const statistics = catalogService.getCatalogStatistics();
  response.json({ status: true, payload: statistics });
});

routerHandler.get('/interactions', (request, response) => {
  const interactions = catalogService.getUserInteractions();
  response.json({ status: true, payload: interactions });
});

// Panel de control avanzado
routerHandler.get('/analytics', (request, response) => {
  const analyticsData = catalogService.getDetailedAnalytics();
  response.json({ status: true, payload: analyticsData });
});

routerHandler.get('/notifications', (request, response) => {
  const catalogItems = catalogService.getAllCatalogItems();
  const systemNotifications = {
    critical: catalogItems.filter(item => item.stock === 0),
    warning: catalogItems.filter(item => item.stock > 0 && item.stock <= 2),
    low: catalogItems.filter(item => item.stock > 2 && item.stock <= 5),
  };
  
  response.json({
    status: true,
    payload: {
      notifications: systemNotifications,
      overview: {
        criticalCount: systemNotifications.critical.length,
        warningCount: systemNotifications.warning.length,
        lowCount: systemNotifications.low.length
      }
    }
  });
});

module.exports = routerHandler;