// routes/catalog.js
const express = require('express');
const routerHandler = express.Router();
const catalogService = require('../services/catalog');

// Obtener todos los artículos del catálogo
routerHandler.get('/', (request, response) => {
  try {
    const catalogItems = catalogService.getAllCatalogItems();
    response.json({ status: true, payload: catalogItems });
  } catch (errorInstance) {
    response.status(500).json({ status: false, message: errorInstance.message });
  }
});

// Obtener artículo por identificador
routerHandler.get('/:identifier', (request, response) => {
  const itemIdentifier = request.params.identifier;
  const catalogItem = catalogService.getCatalogItemById(itemIdentifier);
  
  if (!catalogItem) {
    return response.status(404).json({ 
      status: false, 
      message: 'Catalog item not found' 
    });
  }
  
  response.json({ status: true, payload: catalogItem });
});

// Obtener artículos por clasificación
routerHandler.get('/classification/:classification', (request, response) => {
  const itemClassification = request.params.classification;
  const filteredItems = catalogService.getCatalogItemsByClassification(itemClassification);
  response.json({ status: true, payload: filteredItems });
});

// Buscar artículos
routerHandler.get('/lookup/:searchTerm', (request, response) => {
  const searchTerm = request.params.searchTerm;
  const searchResults = catalogService.findCatalogItems(searchTerm);
  response.json({ status: true, payload: searchResults });
});

module.exports = routerHandler;