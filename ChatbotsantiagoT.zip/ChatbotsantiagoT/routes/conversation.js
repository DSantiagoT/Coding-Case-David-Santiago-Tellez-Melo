const express = require('express');
const routerHandler = express.Router();
const conversationHandler = require('../services/conversationHandler');

routerHandler.post('/communicate', async (request, response) => {
  try {
    const { content, userIdentifier } = request.body;
    
    if (!content) {
      return response.status(400).json({ 
        status: false, 
        message: 'Content is mandatory' 
      });
    }
    
    const aiResponse = await conversationHandler.handleUserMessage(content, userIdentifier);
    
    response.json({ 
      status: true, 
      payload: { 
        userContent: content, 
        aiReply: aiResponse, 
        createdAt: new Date() 
      } 
    });
    
  } catch (errorInstance) {
    response.status(500).json({ 
      status: false, 
      message: errorInstance.message 
    });
  }
});

module.exports = routerHandler;