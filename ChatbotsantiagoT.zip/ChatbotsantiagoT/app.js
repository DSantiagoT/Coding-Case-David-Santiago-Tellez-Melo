require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createServer } = require('http');
const { Server } = require('socket.io');

const catalogRoutes = require('./routes/catalog');
const conversationRoutes = require('./routes/conversation');
const analyticsRoutes = require('./routes/analytics');
const recommendationsRoutes = require('./routes/recommendations');
const { setupSocketConnection } = require('./services/socketHandler');

const application = express();
const httpServer = createServer(application);
const socketInterface = new Server(httpServer, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

application.use(cors());
application.use(express.json());

application.use('/api/catalog', catalogRoutes);
application.use('/api/conversation', conversationRoutes);
application.use('/api/analytics', analyticsRoutes);
application.use('/api/recommendations', recommendationsRoutes);

application.get('/api/status', (request, response) => {
  response.json({ 
    condition: 'ACTIVE', 
    notification: 'Digital Creators API is operational' 
  });
});

setupSocketConnection(socketInterface);

const SERVER_PORT = process.env.PORT || 5000;
httpServer.listen(SERVER_PORT, () => {
  console.log(`🚀 Application server running on port ${SERVER_PORT}`);
});