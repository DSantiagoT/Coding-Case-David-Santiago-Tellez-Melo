const { v4: generateUniqueId } = require('uuid');

class CatalogService {
  constructor() {
    this.catalogItems = [
      {
        identifier: generateUniqueId(),
        name: "HP Pavilion 15",
        brand: "HP",
        classification: "laptop",
        price: 899.99,
        stock: 3,
        specifications: {
          processor: "Intel Core i5-12400H",
          ram: "8GB DDR4",
          storage: "512GB SSD",
          graphics: "Intel Iris Xe",
          screen: "15.6\" Full HD"
        },
        features: ["Backlit keyboard", "Fingerprint reader", "Wi-Fi 6"],
        addedAt: new Date()
      },
      {
        identifier: generateUniqueId(),
        name: "Dell XPS 13",
        brand: "Dell",
        classification: "laptop",
        price: 1299.99,
        stock: 2,
        specifications: {
          processor: "Intel Core i7-1250U",
          ram: "16GB LPDDR5",
          storage: "512GB NVMe SSD",
          graphics: "Intel Iris Xe",
          screen: "13.4\" 4K UHD+"
        },
        features: ["InfinityEdge display", "Carbon fiber palm rest", "Thunderbolt 4"],
        addedAt: new Date()
      },
      {
        identifier: generateUniqueId(),
        name: "MacBook Air M2",
        brand: "Apple",
        classification: "laptop",
        price: 1199.99,
        stock: 1,
        specifications: {
          processor: "Apple M2 chip",
          ram: "8GB unified memory",
          storage: "256GB SSD",
          graphics: "8-core GPU",
          screen: "13.6\" Liquid Retina"
        },
        features: ["Touch ID", "MagSafe charging", "Up to 18 hours battery"],
        addedAt: new Date()
      },
      {
        identifier: generateUniqueId(),
        name: "Gaming Mouse Razer DeathAdder V3",
        brand: "Razer",
        classification: "accessories",
        price: 89.99,
        stock: 15,
        specifications: {
          sensor: "Focus Pro 30K",
          dpi: "30,000 DPI",
          buttons: "8 programmable buttons",
          connectivity: "Wired/Wireless"
        },
        features: ["RGB lighting", "90-hour battery", "Ergonomic design"],
        addedAt: new Date()
      },
      {
        identifier: generateUniqueId(),
        name: "Mechanical Keyboard Corsair K95",
        brand: "Corsair",
        classification: "accessories",
        price: 199.99,
        stock: 8,
        specifications: {
          switches: "Cherry MX RGB",
          layout: "Full-size",
          connectivity: "USB-C",
          backlighting: "Per-key RGB"
        },
        features: ["Dedicated macro keys", "Media controls", "Aluminum frame"],
        addedAt: new Date()
      }
    ];
    this.userInteractions = [];
    this.userProfiles = [];
  }

  // --- Métodos del Catálogo ---
  getAllCatalogItems() {
    return this.catalogItems;
  }

  getCatalogItemById(itemIdentifier) {
    return this.catalogItems.find(item => item.identifier === itemIdentifier);
  }

  getCatalogItemsByClassification(classification) {
    return this.catalogItems.filter(item => 
      item.classification.toLowerCase() === classification.toLowerCase()
    );
  }

  getCatalogItemsByBrand(brand) {
    return this.catalogItems.filter(item => 
      item.brand.toLowerCase().includes(brand.toLowerCase())
    );
  }

  findCatalogItems(searchTerm) {
    const normalizedTerm = searchTerm.toLowerCase();
    return this.catalogItems.filter(item =>
      item.name.toLowerCase().includes(normalizedTerm) ||
      item.brand.toLowerCase().includes(normalizedTerm) ||
      item.classification.toLowerCase().includes(normalizedTerm) ||
      item.features.some(feature => feature.toLowerCase().includes(normalizedTerm))
    );
  }

  modifyStock(itemIdentifier, newQuantity) {
    const catalogItem = this.getCatalogItemById(itemIdentifier);
    if (catalogItem) { 
      catalogItem.stock = newQuantity; 
      return catalogItem; 
    }
    return null;
  }

  // --- Métodos de Análisis ---
  getCatalogStatistics() {
    const totalInventoryValue = this.catalogItems.reduce((accumulator, item) => 
      accumulator + item.price * item.stock, 0
    );
    
    const lowStockItems = this.catalogItems.filter(item => item.stock < 5);
    
    const classificationDistribution = this.catalogItems.reduce((accumulator, item) => {
      accumulator[item.classification] = (accumulator[item.classification] || 0) + 1;
      return accumulator;
    }, {});
    
    const brandInventory = this.catalogItems.reduce((accumulator, item) => {
      accumulator[item.brand] = (accumulator[item.brand] || 0) + item.stock;
      return accumulator;
    }, {});
    
    return {
      totalCatalogItems: this.catalogItems.length,
      totalInventoryValue: Math.round(totalInventoryValue),
      lowStockItems: lowStockItems.length,
      classificationDistribution,
      brandInventory
    };
  }

  recordUserInteraction(userIdentifier, content, aiReply) {
    this.userInteractions.push({ 
      identifier: generateUniqueId(), 
      userIdentifier, 
      content, 
      aiReply, 
      createdAt: new Date() 
    });
  }

  getUserInteractions() { 
    return this.userInteractions; 
  }

  // --- Gestión de Perfiles de Usuario ---
  createUserProfile(userIdentifier, userSettings = {}) {
    const existingProfile = this.userProfiles.find(profile => profile.identifier === userIdentifier);
    
    if (existingProfile) {
      existingProfile.configuration = { ...existingProfile.configuration, ...userSettings };
      existingProfile.lastInteraction = new Date();
      return existingProfile;
    }
    
    const newProfile = {
      identifier: userIdentifier,
      configuration: {
        budgetLimit: userSettings.budgetLimit || 1000,
        preferredClassification: userSettings.preferredClassification || 'laptop',
        favoredBrands: userSettings.favoredBrands || [],
        ...userSettings
      },
      transactionHistory: [],
      lastInteraction: new Date()
    };
    
    this.userProfiles.push(newProfile);
    return newProfile;
  }

  getUserProfileById(userIdentifier) { 
    return this.userProfiles.find(profile => profile.identifier === userIdentifier); 
  }

  // Sistema de Sugerencias
  fetchUserSuggestions(userIdentifier) {
    let userProfile = this.getUserProfileById(userIdentifier);
    if (!userProfile) userProfile = this.createUserProfile(userIdentifier);

    const { budgetLimit, preferredClassification, favoredBrands } = userProfile.configuration;
    const suggestionGroups = { 
      highPriority: [], 
      moderate: [], 
      lowPriority: [] 
    };

    this.catalogItems.forEach(item => {
      let relevanceScore = 0; 
      let scoringReasons = [];
      
      if (item.price <= budgetLimit) { 
        relevanceScore += 3; 
        scoringReasons.push('Within budget'); 
      } else if (item.price <= budgetLimit * 1.15) { 
        relevanceScore += 1; 
        scoringReasons.push('Slightly over budget'); 
      }
      
      if (item.classification === preferredClassification) { 
        relevanceScore += 2.5; 
        scoringReasons.push('Preferred classification'); 
      }
      
      if (favoredBrands.includes(item.brand)) { 
        relevanceScore += 2; 
        scoringReasons.push('Favored brand'); 
      }
      
      if (item.stock > 5) { 
        relevanceScore += 1.5; 
        scoringReasons.push('Excellent availability'); 
      } else if (item.stock > 0) { 
        relevanceScore += 0.5; 
        scoringReasons.push('Limited availability'); 
      }
      
      const categoryItems = this.catalogItems.filter(catalogItem => 
        catalogItem.classification === item.classification
      );
      const averagePrice = categoryItems.reduce((sum, catalogItem) => 
        sum + catalogItem.price, 0
      ) / categoryItems.length;
      
      if (item.price < averagePrice * 0.9) { 
        relevanceScore += 1; 
        scoringReasons.push('Exceptional value'); 
      }

      const suggestionEntry = { 
        ...item, 
        relevanceScore: Math.round(relevanceScore * 10) / 10, 
        scoringReasons 
      };
      
      if (relevanceScore >= 6) suggestionGroups.highPriority.push(suggestionEntry);
      else if (relevanceScore >= 3) suggestionGroups.moderate.push(suggestionEntry);
      else suggestionGroups.lowPriority.push(suggestionEntry);
    });

    ['highPriority', 'moderate', 'lowPriority'].forEach(priority => {
      suggestionGroups[priority] = suggestionGroups[priority].sort((itemA, itemB) => 
        itemB.relevanceScore - itemA.relevanceScore
      );
    });

    return { 
      userIdentifier, 
      userConfiguration: userProfile.configuration, 
      suggestions: suggestionGroups, 
      compiledAt: new Date() 
    };
  }

  recordUserActivity(userIdentifier, activityType, itemIdentifier) {
    let userProfile = this.getUserProfileById(userIdentifier);
    if (!userProfile) userProfile = this.createUserProfile(userIdentifier);
    
    const catalogItem = this.getCatalogItemById(itemIdentifier);
    if (!catalogItem) return;

    switch (activityType) {
      case 'browse':
        if (catalogItem.price > userProfile.configuration.budgetLimit) {
          userProfile.configuration.budgetLimit = Math.min(
            userProfile.configuration.budgetLimit * 1.05, 
            catalogItem.price * 1.1
          );
        }
        break;
        
      case 'inquire':
        if (!userProfile.configuration.favoredBrands.includes(catalogItem.brand)) {
          userProfile.configuration.favoredBrands.push(catalogItem.brand);
        }
        userProfile.configuration.preferredClassification = catalogItem.classification;
        break;
        
      case 'acquire':
        userProfile.transactionHistory.push({ 
          itemIdentifier, 
          cost: catalogItem.price, 
          transactionDate: new Date() 
        });
        userProfile.configuration.preferredClassification = catalogItem.classification;
        if (!userProfile.configuration.favoredBrands.includes(catalogItem.brand)) {
          userProfile.configuration.favoredBrands.push(catalogItem.brand);
        }
        break;
    }
    
    userProfile.lastInteraction = new Date();
    return userProfile;
  }

  // Método para análisis avanzados
  getDetailedAnalytics() {
    const basicStats = this.getCatalogStatistics();
    const interactionMetrics = {
      totalInteractions: this.userInteractions.length,
      activeUsers: new Set(this.userInteractions.map(interaction => 
        interaction.userIdentifier
      )).size,
      averageInteractionsPerUser: this.userInteractions.length / Math.max(1, this.userProfiles.length)
    };
    
    return {
      catalogMetrics: basicStats,
      userEngagement: interactionMetrics,
      lastUpdated: new Date()
    };
  }
}

module.exports = new CatalogService();