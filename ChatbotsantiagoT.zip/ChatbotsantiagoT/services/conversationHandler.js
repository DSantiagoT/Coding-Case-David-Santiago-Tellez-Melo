const OpenAI = require('openai');
const catalogService = require('../services/catalog');

class ConversationHandler {
  constructor() {
    this.aiClient = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }

  async handleUserMessage(content, userIdentifier = 'guest') {
    try {
      // --- INICIO: respuestas predefinidas para los botones (frases nuevas) ---
      const normalized = (content || '').trim();

      // Nuevas frases exactas que interceptamos:
      if (normalized === '¿Qué dispositivos portátiles tienen?') {
        const items = catalogService.getAllCatalogItems();
        const portableDevices = items.filter(it => (it.classification || '').toLowerCase() === 'laptop' || (it.classification || '').toLowerCase() === 'portátil' );
        const totalUnits = portableDevices.reduce((acc, device) => acc + (device.stock || 0), 0);
        const details = portableDevices.length
          ? portableDevices.map(d => `${d.stock} x ${d.brand} ${d.name}`).join(', ')
          : 'No hay dispositivos portátiles registrados en el catálogo.';
        const reply = portableDevices.length
          ? `Actualmente tenemos ${totalUnits} dispositivos portátiles en inventario: ${details}. ¿Te muestro especificaciones o precios de alguno en particular?`
          : details;
        catalogService.recordUserInteraction(userIdentifier, content, reply);
        return reply;
      }

      if (normalized === '¿Cuáles son los productos más vendidos?') {
        const items = catalogService.getAllCatalogItems();
        // Usamos stock como proxy de popularidad; mostramos hasta 4
        const top = items
          .slice()
          .sort((a, b) => (b.stock || 0) - (a.stock || 0))
          .slice(0, 4)
          .map(it => `${it.name} (${it.brand}) — ${it.stock} unidades`);
        const reply = top.length
          ? `Productos más vendidos / con mayor disponibilidad:\n- ${top.join('\n- ')}\n¿Quieres ver precios o especificaciones de alguno?`
          : 'No hay datos de productos para mostrar en este momento.';
        catalogService.recordUserInteraction(userIdentifier, content, reply);
        return reply;
      }

      if (normalized === '¿Hay descuentos disponibles?') {
        const items = catalogService.getAllCatalogItems();
        const offers = items.filter(it =>
          (it.offer && it.offer.active) ||
          (typeof it.discount === 'number' && it.discount > 0) ||
          it.onOffer === true
        );

        const reply = offers.length
          ? `Actualmente hay ${offers.length} producto(s) con descuento:\n${offers.map(it => {
              const disc = it.discount ? ` - descuento ${it.discount}%` : '';
              const price = it.price ? ` Precio: $${it.price}` : '';
              return `• ${it.name} (${it.brand})${price}${disc}`;
            }).join('\n')}\n¿Quieres que te envíe la lista ordenada por mayor descuento?`
          : 'En este momento no hay descuentos activos. ¿Deseas que te notifique cuando haya alguno?';
        catalogService.recordUserInteraction(userIdentifier, content, reply);
        return reply;
      }

      if (normalized === 'Necesito una sugerencia personalizada') {
        const reply = `Perfecto — para darte una recomendación personalizada, dime por favor: 1) ¿Para qué usarás el equipo (ofimática, gaming, edición de video, desarrollo, movilidad)? 2) ¿Cuál es tu rango de presupuesto aproximado? Con eso te propongo 2 o 3 opciones.`;
        catalogService.recordUserInteraction(userIdentifier, content, reply);
        return reply;
      }
      // --- FIN: respuestas predefinidas para los botones ---

      // Si no es ninguna de las opciones predefinidas, seguir con el flujo normal:
      const catalogItems = catalogService.getAllCatalogItems();
      const catalogContext = catalogItems.map(item => 
        `- ${item.name} (${item.brand}): $${item.price}, Stock: ${item.stock}`
      ).join('\n');

      const systemInstructions = `Eres un consultor especializado en ventas para Digital Creators Platform, una plataforma de tecnología avanzada.

CATÁLOGO DISPONIBLE:
${catalogContext}

DIRECTRICES:
- Mantén un tono cordial y profesional en español
- Utiliza la información del catálogo para responder consultas específicas
- Cuando consulten sobre disponibilidad, proporciona cifras exactas del catálogo
- Ofrece alternativas cuando sea pertinente
- Proporciona respuestas breves pero completas
- Si careces de información específica, admítelo con transparencia

Ejemplo de respuesta para "¿cuántos dispositivos tienen disponibles?":
"Actualmente tenemos 6 dispositivos portátiles en inventario: 3 HP Pavilion 15, 2 Dell XPS 13, y 1 MacBook Air M2. ¿Alguno llama tu atención?"`;

      const aiCompletion = await this.aiClient.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: systemInstructions },
          { role: "user", content: content }
        ],
        max_tokens: 200,
        temperature: 0.7
      });

      const aiReply = aiCompletion.choices[0].message.content;
      catalogService.recordUserInteraction(userIdentifier, content, aiReply);
      return aiReply;

    } catch (errorInstance) {
      console.error('AI Service Error:', errorInstance);
      return this.generateFallbackResponse(content);
    }
  }

  generateFallbackResponse(content) {
    const normalizedContent = content.toLowerCase();

    if (normalizedContent.includes('computadora') || normalizedContent.includes('laptop')) {
      const portableDevices = catalogService.getCatalogItemsByClassification('laptop');
      const totalUnits = portableDevices.reduce((accumulator, device) => accumulator + device.stock, 0);
      return `Disponemos de ${totalUnits} equipos portátiles: ${portableDevices.map(device => 
        `${device.stock} ${device.brand}`).join(', ')}. ¿Alguna marca te interesa especialmente?`;
    }

    if (normalizedContent.includes('precio') && normalizedContent.includes('dell')) {
      const dellDevices = catalogService.getCatalogItemsByBrand('Dell');
      const primaryDell = dellDevices[0];
      return primaryDell ? 
        `El ${primaryDell.name} tiene un precio de $${primaryDell.price} y contamos con ${primaryDell.stock} unidades disponibles.` : 
        'No contamos con productos Dell en este momento.';
    }

    return 'Aprecio tu consulta. Puedes preguntarme sobre inventario, costos o especificaciones. ¿En qué aspecto específico puedo asistirte?';
  }
}

module.exports = new ConversationHandler();
