const conversationHandler = require('./conversationHandler');

function setupSocketConnection(socketInterface) {
  socketInterface.on('connection', (clientSocket) => {
    console.log(`Client connected: ${clientSocket.id}`);

    // Unir cliente a una sala específica (para conversaciones individualizadas)
    clientSocket.on('join-conversation', (userIdentifier) => {
      clientSocket.join(`client-${userIdentifier}`);
      clientSocket.emit('conversation-joined', { 
        userIdentifier, 
        connectionId: clientSocket.id 
      });
    });

    // Manejar mensajes de conversación via WebSocket
    clientSocket.on('transmit-content', async (messageData) => {
      try {
        const { content, userIdentifier } = messageData;
        const aiReply = await conversationHandler.handleUserMessage(content, userIdentifier);

        // Enviar respuesta de vuelta al cliente
        clientSocket.emit('receive-content', {
          userContent: content,
          aiResponse: aiReply,
          createdAt: new Date()
        });

        // Opcional: Difundir al panel administrativo
        clientSocket.broadcast.emit('new-interaction', {
          userIdentifier,
          userContent: content,
          aiResponse: aiReply,
          createdAt: new Date()
        });
      } catch (errorInstance) {
        clientSocket.emit('connection-error', { 
          notification: 'Error processing user content' 
        });
      }
    });

    clientSocket.on('disconnect', () => {
      console.log(`Client disconnected: ${clientSocket.id}`);
    });
  });
}

module.exports = { setupSocketConnection };